# i18n-config [![crates.io badge](https://img.shields.io/crates/v/i18n-config.svg)](https://crates.io/crates/i18n-config) [![docs.rs badge](https://docs.rs/i18n-config/badge.svg)](https://docs.rs/i18n-config/) [![license badge](https://img.shields.io/github/license/kellpossible/cargo-i18n)](https://github.com/kellpossible/cargo-i18n/blob/master/i18n-config/LICENSE.txt) [![github actions badge](https://github.com/kellpossible/cargo-i18n/workflows/Rust/badge.svg)](https://github.com/kellpossible/cargo-i18n/actions?query=workflow%3ARust)

This library contains the configuration structs (along with their parsing functions) for the [cargo-i18n](https://crates.io/crates/cargo_i18n) tool/system.

**[Changelog](https://github.com/kellpossible/cargo-i18n/blob/master/i18n-config/CHANGELOG.md)**
