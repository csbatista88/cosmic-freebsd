Apply
=====

A tiny library for chaining free functions into method call chains.

Usage
-----

See `tests/lib.rs`.