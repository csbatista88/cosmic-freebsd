# async-signal

![CI](https://github.com/Sherlock-Holo/async-signals/workflows/CI/badge.svg)

Library for easier and safe Unix signal handling with async Stream.

You can use this crate with any async runtime.
