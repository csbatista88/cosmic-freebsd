# d3d12-rs
[![Crates.io](https://img.shields.io/crates/v/d3d12.svg)](https://crates.io/crates/d3d12)
[![Docs.rs](https://docs.rs/d3d12/badge.svg)](https://docs.rs/d3d12)

Rust wrapper for raw D3D12 access.
