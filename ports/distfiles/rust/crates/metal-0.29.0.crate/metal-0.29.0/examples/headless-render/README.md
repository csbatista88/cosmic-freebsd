## headless-render

Renders the triangle from the [window example](../window) headlessly and then writes it to a PNG file.

![Screenshot of the final render](./screenshot.png)

## To Run

```
cargo run --example headless-render
```
