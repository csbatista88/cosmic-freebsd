# pixman-sys

Low-level ffi bindings for [`pixman`](https://www.pixman.org/).