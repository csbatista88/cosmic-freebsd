fn main() {
    println!("cargo:rustc-link-lib=pixman-1");
}
