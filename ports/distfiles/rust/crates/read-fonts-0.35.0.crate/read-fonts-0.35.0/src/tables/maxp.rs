//! The [maxp](https://docs.microsoft.com/en-us/typography/opentype/spec/maxp) table

include!("../../generated/generated_maxp.rs");
