# libdisplay-info-sys

Low-level ffi bindings for [`libdisplay-info`](https://gitlab.freedesktop.org/emersion/libdisplay-info/).