# To be removed
Only remove after Plasma 5 and KF 5 releases end.

* fullscreen-shell.xml: It's upstream https://gitlab.freedesktop.org/wayland/wayland-protocols/-/tree/master/unstable
* remote-access.xml: Deprecated in favor of screencast.xml
* surface-extension.xml: Deprecated in Qt, not used anymore
* wayland-eglstream-controller.xml: to be removed and moved to kwin, no other component in KDE should care about this, neither others. It's not a protocol we own.
* remove the legacy install name of zkde-screencast-unstable-v1
