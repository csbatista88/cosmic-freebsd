# Attribution

Much of the code in this module/folder is heavily based on and largely copy-pasted from the the
[sublimate](https://github.com/defuz/sublimate) project by
[Ivan Ivashchenko a.k.a @defuz](https://github.com/defuz). The project was released under the MIT license.

I needed to copy-paste the code here because it required some adaptations to work with the other
parts of syntect. One example modification is using my bit-packed `Scope` type instead of the
original string-based one.
