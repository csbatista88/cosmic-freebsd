// SPDX-License-Identifier: Apache-2.0 OR MIT

#[cfg(feature = "transpose_methods")]
pub(crate) mod transpose;
