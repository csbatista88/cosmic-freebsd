# lyon::tessellation

Tessellation of filled and stroked 2D paths.

<p align="center">
  <a href="https://crates.io/crates/lyon_tessellation">
      <img src="https://img.shields.io/crates/v/lyon_tessellation.svg" alt="crates.io">
  </a>
  <a href="https://docs.rs/lyon_tessellation">
      <img src="https://docs.rs/lyon_tessellation/badge.svg" alt="documentation">
  </a>
</p>

`lyon_tessellation` can be used as a standalone crate or as part of [lyon](https://docs.rs/lyon/) via the `lyon::tessellation` module.

