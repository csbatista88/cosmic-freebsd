# pipewire [![](https://img.shields.io/crates/v/pipewire.svg)](https://crates.io/crates/pipewire) [![](https://docs.rs/pipewire/badge.svg)](https://docs.rs/pipewire)

[PipeWire](https://pipewire.org) bindings for Rust.

These bindings are providing a safe API that can be used to interface with
[PipeWire](https://pipewire.org).

## Documentation

See the [crate documentation](https://pipewire.pages.freedesktop.org/pipewire-rs/pipewire/).