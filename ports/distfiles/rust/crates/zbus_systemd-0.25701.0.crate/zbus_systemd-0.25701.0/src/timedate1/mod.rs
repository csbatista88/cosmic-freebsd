//! D-Bus interface for systemd-timedated ([org.freedesktop.timedate1](https://www.freedesktop.org/software/systemd/man/org.freedesktop.timedate1.html)).

mod generated;
pub use generated::*;
