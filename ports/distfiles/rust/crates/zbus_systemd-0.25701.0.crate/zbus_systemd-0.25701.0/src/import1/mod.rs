//! D-Bus interface for systemd-importd ([org.freedesktop.import1](https://www.freedesktop.org/software/systemd/man/org.freedesktop.import1.html)).

mod generated;
pub use generated::*;
