//! D-Bus interface for systemd-timesyncd ([org.freedesktop.timesync1](https://www.freedesktop.org/software/systemd/man/org.freedesktop.timesync1.html)).
mod generated;
pub use generated::*;
