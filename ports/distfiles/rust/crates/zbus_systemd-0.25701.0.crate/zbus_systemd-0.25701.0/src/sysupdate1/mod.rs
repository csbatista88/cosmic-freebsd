//! D-Bus interface for systemd-sysupdated ([org.freedesktop.sysupdate1](https://www.freedesktop.org/software/systemd/man/org.freedesktop.sysupdate1.html)).
mod generated;
pub use generated::*;
