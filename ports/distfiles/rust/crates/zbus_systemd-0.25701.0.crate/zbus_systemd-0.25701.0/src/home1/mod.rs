//! D-Bus interface for systemd-homed ([org.freedesktop.home1](https://www.freedesktop.org/software/systemd/man/org.freedesktop.home1.html)).

mod generated;
pub use generated::*;
