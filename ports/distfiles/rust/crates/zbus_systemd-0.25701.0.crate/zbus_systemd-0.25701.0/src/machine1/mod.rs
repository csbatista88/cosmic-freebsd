//! D-Bus interface for systemd-machined ([org.freedesktop.machine1](https://www.freedesktop.org/software/systemd/man/org.freedesktop.machine1.html)).

mod generated;
pub use generated::*;
