//! D-Bus interface for systemd ([org.freedesktop.systemd1](https://www.freedesktop.org/software/systemd/man/org.freedesktop.systemd1.html)).

mod generated;
pub use generated::*;
