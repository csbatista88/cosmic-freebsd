//! D-Bus interface for systemd-localed ([org.freedesktop.locale1](https://www.freedesktop.org/software/systemd/man/org.freedesktop.locale1.html)).

mod generated;
pub use generated::*;
