//! D-Bus interface for systemd-oomd ([org.freedesktop.oom1](https://www.freedesktop.org/software/systemd/man/org.freedesktop.oom1.html)).

mod generated;
pub use generated::*;
