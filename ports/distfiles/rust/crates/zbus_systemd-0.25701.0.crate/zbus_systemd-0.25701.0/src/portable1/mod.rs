//! D-Bus interface for systemd-portabled ([org.freedesktop.portable1](https://www.freedesktop.org/software/systemd/man/org.freedesktop.portable1.html)).

mod generated;
pub use generated::*;
