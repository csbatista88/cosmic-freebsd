//! D-Bus interface for systemd-logind ([org.freedesktop.login1](https://www.freedesktop.org/software/systemd/man/org.freedesktop.login1.html)).

mod generated;
pub use generated::*;
