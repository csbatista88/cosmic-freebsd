//! D-Bus interface for systemd-resolved ([org.freedesktop.resolve1](https://www.freedesktop.org/software/systemd/man/org.freedesktop.resolve1.html)).

mod generated;
pub use generated::*;
