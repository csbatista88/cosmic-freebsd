//! D-Bus interface for systemd-networkd ([org.freedesktop.network1](https://www.freedesktop.org/software/systemd/man/org.freedesktop.network1.html)).

mod generated;
pub use generated::*;
