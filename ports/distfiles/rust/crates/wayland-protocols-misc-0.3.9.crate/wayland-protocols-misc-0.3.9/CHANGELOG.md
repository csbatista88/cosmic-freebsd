# CHANGELOG: wayland-protocols-misc

## Unreleased

## 0.3.0 -- 2024-05-30

### Breaking changes
- Updated wayland-protocols to 0.3

## 0.2.0 -- 2023-09-02

### Breaking changes

- Bump bitflags to 2.0
- Updated wayland-backend to 0.3

## 0.1.0 -- 27/12/2022

## 0.1.0-beta.5

### Additions

- Introduce protocol `virtual-keyboard-unstable-v1`.
