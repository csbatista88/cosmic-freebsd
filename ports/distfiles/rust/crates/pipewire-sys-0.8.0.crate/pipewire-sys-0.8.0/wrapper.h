#include <pipewire/pipewire.h>
#include <pipewire/extensions/client-node.h>
#include <pipewire/extensions/metadata.h>
#include <pipewire/extensions/profiler.h>
#include <pipewire/extensions/protocol-native.h>
#include <pipewire/extensions/session-manager.h>