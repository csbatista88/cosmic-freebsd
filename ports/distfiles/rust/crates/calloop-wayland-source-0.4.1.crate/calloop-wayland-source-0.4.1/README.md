# calloop-wayland-source

Use [`EventQueue`] from the [`wayland-client`](https://crates.io/crates/wayland-client)
with the [`calloop`](https://crates.io/crates/calloop).

[`EventQueue`]: https://docs.rs/wayland-client/0.30/wayland_client/struct.EventQueue.html
