# CHANGELOG: wayland-protocols-experimental

## Unreleased

## 20250721.0.1 -- 2025-07-28

### Additions

- Introduce protocol `session_management-v1`,
- Introduce protocol `input_method-v2`.

### Breaking changes

- Bump `input_method-v2` to version 2.
