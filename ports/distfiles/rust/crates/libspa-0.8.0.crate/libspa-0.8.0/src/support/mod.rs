// Copyright The pipewire-rs Contributors.
// SPDX-License-Identifier: MIT

pub mod system;
