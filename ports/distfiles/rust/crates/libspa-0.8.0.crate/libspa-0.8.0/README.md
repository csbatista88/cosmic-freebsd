# libspa [![](https://img.shields.io/crates/v/libspa.svg)](https://crates.io/crates/libspa) [![](https://docs.rs/libspa/badge.svg)](https://docs.rs/libspa)

[libspa](https://pipewire.org) bindings for Rust.

These bindings are providing a safe API that can be used to interface with
[libspa](https://pipewire.org).

## Documentation

See the [crate documentation](https://pipewire.pages.freedesktop.org/pipewire-rs/libspa/).